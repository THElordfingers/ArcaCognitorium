# Agentia Architecturalis — tests/test_integration.py
# v1.0.0
import ast
import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from AgentiaArchitecturalis.elements.factory import create_element, deserialize_element
from AgentiaArchitecturalis.library import ComponentLibrary
from AgentiaArchitecturalis.codegen import generate_code
from AgentiaArchitecturalis.constants import MODUS_ARCANUS_DEFAULTS


class TestIntegration(unittest.TestCase):
    def test_full_critical_path(self):
        # 1. Create element tree
        frame = create_element('QFrame')
        frame.properties['variable_name'] = 'test_frame'

        # 2. Add QLabel child
        label = create_element('QLabel_gold')
        label.properties['label_text'] = 'Titulus'
        label.properties['text_token'] = 'c_gold'
        frame.children.append(label)

        # 3. Add button child
        btn = create_element('ArcaneButton_teal')
        btn.properties['label_text'] = '\u2697 Manifest'
        frame.children.append(btn)

        # 4. Serialize
        tree = [frame.serialize()]
        self.assertEqual(len(tree), 1)
        self.assertEqual(len(tree[0]['children']), 2)

        # 5. Save to library
        tmp = TemporaryDirectory()
        lib = ComponentLibrary(Path(tmp.name) / 'test.db')
        lib.initialize()
        design_doc = {
            'schema_version': '1.0',
            'canvas_width': 2000, 'canvas_height': 2000,
            'root_elements': tree,
            'theme_designator': None, 'metadata': {},
        }
        cid = lib.save('Test Panel', 'panel', json.dumps(design_doc))

        # 6. Load back
        row = lib.load(cid)
        loaded = json.loads(row['design_json'])
        self.assertEqual(len(loaded['root_elements']), 1)

        # 7. Deserialize
        restored_root = deserialize_element(loaded['root_elements'][0])
        self.assertEqual(len(restored_root.children), 2)

        # 8. Generate code
        code = generate_code(loaded, MODUS_ARCANUS_DEFAULTS)
        ast.parse(code)  # no SyntaxError

        # 9. Verify code contents
        self.assertIn('QFrame', code)
        self.assertIn('QLabel', code)
        self.assertIn('QPushButton', code)
        self.assertIn('C_C_GOLD', code)

        # 10. Fork
        fid = lib.fork(cid, 'Test Panel (fork)')
        forked = lib.load(fid)
        self.assertEqual(forked['parent_id'], cid)

        lib.close()
        tmp.cleanup()

if __name__ == '__main__':
    unittest.main()
