# Agentia Architecturalis — tests/test_canvas.py
# v1.0.0
import unittest
from AgentiaArchitecturalis.elements.factory import create_element, deserialize_element


class TestCanvasLogic(unittest.TestCase):
    """Tests canvas element operations without QGraphicsScene (headless)."""

    def test_add_child_to_container(self):
        frame = create_element('QFrame')
        label = create_element('QLabel_gold')
        frame.children.append(label)
        self.assertEqual(len(frame.children), 1)
        self.assertTrue(frame.accepts_children())

    def test_serialize_with_children(self):
        frame = create_element('QFrame')
        label = create_element('QLabel_gold')
        frame.children.append(label)
        data = frame.serialize()
        self.assertEqual(len(data['children']), 1)
        self.assertEqual(data['children'][0]['element_type'], 'QLabel_gold')

    def test_deserialize_roundtrip(self):
        frame = create_element('QFrame')
        label = create_element('QLabel_gold')
        label.properties['label_text'] = 'Test Title'
        frame.children.append(label)
        data = frame.serialize()
        restored = deserialize_element(data)
        self.assertEqual(restored.element_type, 'QFrame')
        self.assertEqual(len(restored.children), 1)
        self.assertEqual(restored.children[0].properties['label_text'], 'Test Title')

    def test_non_container_rejects_children(self):
        label = create_element('QLabel_gold')
        self.assertFalse(label.accepts_children())

if __name__ == '__main__':
    unittest.main()
