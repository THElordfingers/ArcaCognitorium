# Agentia Architecturalis — tests/test_elements.py
# v1.0.0
import unittest
from AgentiaArchitecturalis.elements.factory import create_element, list_element_types


class TestElements(unittest.TestCase):
    def test_all_types_instantiate(self):
        for et in list_element_types():
            elem = create_element(et)
            self.assertIsNotNone(elem)

    def test_default_properties_is_dict(self):
        for et in list_element_types():
            elem = create_element(et)
            self.assertIsInstance(elem.properties, dict)

    def test_configurable_properties_non_empty(self):
        for et in list_element_types():
            elem = create_element(et)
            self.assertGreater(len(elem.configurable_properties()), 0, et)

    def test_serialize_has_required_keys(self):
        for et in list_element_types():
            elem = create_element(et)
            s = elem.serialize()
            for key in ('id', 'element_type', 'properties', 'children'):
                self.assertIn(key, s, f'{et} missing {key}')

if __name__ == '__main__':
    unittest.main()
