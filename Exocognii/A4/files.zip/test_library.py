# Agentia Architecturalis — tests/test_library.py
# v1.0.0
import unittest
import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory
from AgentiaArchitecturalis.library import ComponentLibrary


class TestLibrary(unittest.TestCase):
    def setUp(self):
        self._tmp = TemporaryDirectory()
        self._lib = ComponentLibrary(Path(self._tmp.name) / 'test.db')
        self._lib.initialize()

    def tearDown(self):
        self._lib.close()
        self._tmp.cleanup()

    def test_save_and_load(self):
        cid = self._lib.save('Test Panel', 'panel', '{"root_elements":[]}')
        row = self._lib.load(cid)
        self.assertIsNotNone(row)
        self.assertEqual(row['name'], 'Test Panel')
        self.assertEqual(row['version'], 1)

    def test_fork(self):
        cid = self._lib.save('Original', 'panel', '{}')
        fid = self._lib.fork(cid, 'Forked')
        forked = self._lib.load(fid)
        self.assertEqual(forked['parent_id'], cid)
        self.assertEqual(forked['version'], 1)
        self.assertEqual(forked['name'], 'Forked')

    def test_archive_filters(self):
        cid = self._lib.save('A', 'panel', '{}')
        self._lib.save('B', 'panel', '{}')
        self._lib.archive(cid)
        visible = self._lib.list_components()
        self.assertEqual(len(visible), 1)
        self.assertEqual(visible[0]['name'], 'B')

    def test_update_increments_version(self):
        cid = self._lib.save('V', 'panel', '{}')
        self._lib.save('V', 'panel', '{"updated":true}', component_id=cid)
        row = self._lib.load(cid)
        self.assertEqual(row['version'], 2)

if __name__ == '__main__':
    unittest.main()
